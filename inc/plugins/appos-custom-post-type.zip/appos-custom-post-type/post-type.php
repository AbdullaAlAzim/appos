<?php
/**
 * Plugin Name: Appos Custom Post
 * Plugin URI: https://themeforest.net/user/codexcoder
 * Description: This plugin is for appos custom post type
 * Author: CodexCoder
 * Author URI: http://codexcoder.com/
 * Version: 1.0.0
 * Text Domain: appos-custom-post
 */
 
/* 
*	Team postType
 */

if(!class_exists('appos_Team_Post_Type')) :

    class appos_Team_Post_Type {

        public static $post_type        = 'appos_team';
		public static $texonomy_type    = 'appos_team_cat';
        public static $menu_position    = 5;
        public static $text_domain      = 'appos-custom-post';

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Team',  self::$text_domain ),
        'singular_name'      => esc_html__( 'Team', self::$text_domain  ),
        'menu_name'          => esc_html__( 'Teams',  self::$text_domain  ),
        'name_admin_bar'     => esc_html__( 'Team', self::$text_domain  ),
        'add_new'            => esc_html__( 'Add New',  self::$text_domain  ),
        'add_new_item'       => esc_html__( 'Add New Member', self::$text_domain  ),
        'new_item'           => esc_html__( 'New Member', self::$text_domain  ),
        'edit_item'          => esc_html__( 'Edit Member Ditails', self::$text_domain  ),
        'view_item'          => esc_html__( 'View Member', self::$text_domain  ),
        'all_items'          => esc_html__( 'All Teams', self::$text_domain  ),
        'search_items'       => esc_html__( 'Search Member', self::$text_domain  ),
        'parent_item_colon'  => esc_html__( 'Parent Teams:', self::$text_domain  ),
        'not_found'          => esc_html__( 'No Members found.', self::$text_domain  ),
        'not_found_in_trash' => esc_html__( 'No Members found in Trash.', self::$text_domain  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title', 'thumbnail' ),
        'menu_icon'          => 'dashicons-image-filter',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

 /**
 * Texonomy Register
 */

    $port_labels = array(
        'name'              => esc_html__( 'Categories', self::$text_domain ),
        'singular_name'     => esc_html__( 'Category', self::$text_domain ),
        'search_items'      => esc_html__( 'Search Categories', self::$text_domain ),
        'all_items'         => esc_html__( 'All Categories', self::$text_domain ),
        'parent_item'       => esc_html__( 'Parent Category', self::$text_domain ),
        'parent_item_colon' => esc_html__( 'Parent Category:', self::$text_domain ),
        'edit_item'         => esc_html__( 'Edit Category', self::$text_domain ),
        'update_item'       => esc_html__( 'Update Category', self::$text_domain ),
        'add_new_item'      => esc_html__( 'Add New Category', self::$text_domain ),
        'new_item_name'     => esc_html__( 'New Category Name', self::$text_domain ),
        'menu_name'         => esc_html__( 'Categories', self::$text_domain ),
    );

    $port_args = array(
        'hierarchical'      => true,
        'labels'            => $port_labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => self::$texonomy_type ),
    );

    register_taxonomy( self::$texonomy_type , array( self::$post_type ), $port_args );

        }
    }

endif;


/**
 * Pricing Table
 */

if(!class_exists('appos_Pricing_Table')) :

    class appos_Pricing_Table {

        public static $post_type        = 'appos_pricing_table';
        public static $menu_position    = 5;
        public static $text_domain      = 'appos-custom-post';

        public static function register(){

        $labels = array(
        'name'               => esc_html__( 'Pricing Tables',  self::$text_domain ),
        'singular_name'      => esc_html__( 'Pricing Table', self::$text_domain  ),
        'menu_name'          => esc_html__( 'Pricing Tables',  self::$text_domain  ),
        'name_admin_bar'     => esc_html__( 'Pricing Table', self::$text_domain  ),
        'add_new'            => esc_html__( 'Add New',  self::$text_domain  ),
        'add_new_item'       => esc_html__( 'Add New Pricing Table', self::$text_domain  ),
        'new_item'           => esc_html__( 'New Pricing Table', self::$text_domain  ),
        'edit_item'          => esc_html__( 'Edit Pricing Table', self::$text_domain  ),
        'view_item'          => esc_html__( 'View Pricing Table', self::$text_domain  ),
        'all_items'          => esc_html__( 'All Pricing Tables', self::$text_domain  ),
        'search_items'       => esc_html__( 'Search Pricing Tables', self::$text_domain  ),
        'parent_item_colon'  => esc_html__( 'Parent Pricing Tables:', self::$text_domain  ),
        'not_found'          => esc_html__( 'No Pricing Tables found.', self::$text_domain  ),
        'not_found_in_trash' => esc_html__( 'No Pricing Tables found in Trash.', self::$text_domain  )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => self::$post_type ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => self::$menu_position ,
        'supports'           => array( 'title' ),
        'menu_icon'          => 'dashicons-format-aside',

    );

    $args = apply_filters('presscore_post_type_'. self::$post_type. '_args', $args );

    register_post_type( self::$post_type, $args );

    flush_rewrite_rules();

    

        }
    }

endif;
//PostType Registretion
if(!function_exists('appos_custom_post')) :

	function appos_custom_post (){
        appos_Team_Post_Type::register();
        appos_Pricing_Table::register();
	}
endif;

add_action( 'init','appos_custom_post');

//Change Title placeholder
function appos_change_title_text( $title ){
	 $screen = get_current_screen();
  
	 if  ( 'appos_team' == $screen->post_type ) {
		  $title = esc_html__( 'Add Member Name', 'appos-custom-post'  );
	 }
	 if  ( 'appos_pricing_table' == $screen->post_type ) {
		  $title = esc_html__( 'Pricing Type (Ex: Basic, Primary, Premium)', 'appos-custom-post'  );
	 }
  
	 return $title;
}
  
add_filter( 'enter_title_here', 'appos_change_title_text' );
